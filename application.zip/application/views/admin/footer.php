      </div> <!-- end of container -->

      <nav class="navbar navbar-default">

        <div class="container-fluid">
          <p class="navbar-text">Copyright Sancu Creative Indonesia @<?php echo date('Y') ?></p>
          <p class="navbar-text">ver 1.2</p>
        </div>

      </nav>

  <script type="text/javascript" src="<?php echo base_url() ?>asset/js/jquery.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/bootstrap/js/bootstrap.js"></script>
  <!-- datatables js -->
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/datatables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/buttons/js/buttons.bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/buttons/js/buttons.print.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/buttons/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/buttons/js/buttons.flash.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/jszip/jszip.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/pdfmake/pdfmake.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/datatables/pdfmake/vfs_fonts.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/js/adminmain.js"></script>

</body>
</html>
