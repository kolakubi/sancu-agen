<div class="row" style="padding: 10px 10px 30px 10px">
  <p class="text text-center">
    <img src="<?php echo base_url().$fotoprofil ?>" class="img-circle img-responsive" alt="profil" style="margin: 0 auto;">
  </p>
  <h4 class="text-center"><?php echo $nama ?></h4>
  <h4 class="text-center"><?php echo $kota ?></h4>
  <p class="text-center">
    <span class="glyphicon glyphicon-home" aria-hidden="true"></span> <?php echo $alamat ?><br>
    <span class="glyphicon glyphicon-phone" aria-hidden="true"></span> <?php echo $telepon ?><br>
    <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> <?php echo $email ?><br>
  </p>
</div>
<div class="row">
  <div class="col-xs-12">
    <p class="text-center">
      <a class="btn btn-info" href="<?php echo base_url() ?>agen">kembali</a>
    </p>
  </div>
</div>
