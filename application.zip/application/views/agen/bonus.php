<div class="row">
	<h3 class="text-center">Bonus</h3>
	<p class="text-center">
		<a href="<?php echo base_url() ?>agen" class="btn btn-info">Kembali</a>	
	</p>
</div>