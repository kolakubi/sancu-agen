<div class="row">
  <div class="col-xs-12">
    <br><br><br>
    <p class="text-center">
      <img src="<?php echo base_url() ?>asset/image/sad-face.png" alt="sad-face" class="img" style="margin: 0 auto; max-width: 160px;">
    </p>

    <p class="text-center" style="color: red"><strong>Tidak ada transaksi pada tanggal tersebut <br>Silakan ulangi pencarian</strong></p>
  </div>
</div>
<br><br>
<div class="row">
  <div class="col-xs-12">
    <p class="text-center">
      <a class="btn btn-info" href="<?php echo base_url() ?>agen">kembali</a>
    </p>
  </div>
</div>
