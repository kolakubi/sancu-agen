<div class="row">
  <div class="col-xs-12">
    <h5 class="text-center text-danger">Tidak ada transaksi pada tanggal tersebut</h5>
    <h5 class="text-center text-danger">Silakan ulangi pencarian</h5>
  </div>
</div>

<div class="row">
  <div class="col-xs-12">
    <p class="text-center">
      <a class="btn btn-info" href="<?php echo base_url() ?>agen">kembali</a>
    </p>
  </div>
</div>
