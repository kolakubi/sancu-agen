      </div> <!-- end of row -->
    </div> <!-- end of container-->

    <nav class="navbar navbar-default" id="footer" style="background-color: #00abc5">

      <div class="container-fluid">
        <p class="navbar-text" style="color: white;">Copyright Sancu Creative Indonesia @2018</p>
        <p class="navbar-text text-right" style="color: white;">ver 1.2</p>
      </div>

    </nav>

    <script type="text/javascript" src="<?php echo base_url() ?>asset/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>asset/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>asset/js/agenmain.js"></script>

  </body>
</html>
