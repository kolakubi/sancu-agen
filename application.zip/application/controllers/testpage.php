<?php
  class Testpage extends CI_Controller{
    public function bonus(){
      $this->load->view('testpage/bonus');
    }
  }
